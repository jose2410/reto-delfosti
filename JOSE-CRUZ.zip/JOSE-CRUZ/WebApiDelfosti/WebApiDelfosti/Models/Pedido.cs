﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace WebApiDelfosti.Models
{
    public class Pedido
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int NumeroPedido { get; set; }
        [Required]
        public DateTime FechaPedido { get; set; }
        public DateTime FechaRecepcion { get; set; }
        public DateTime FechaDespacho { get; set; }
        public DateTime FechaEntrega { get; set; }
        [Required]
        public int VendedorSolicitante { get; set; }
        [Required]
        public int Repartidor { get; set; }
        public int EstadoPedidoID { get; set; } // Esta es la clave foránea que relaciona a los pedidos con los estados de pedido
        public EstadoPedido Estado { get; set; }
        [ForeignKey("VendedorSolicitante")]
        public Usuario VendedorUsuario { get; set; }

        [ForeignKey("Repartidor")]
        public Usuario RepartidorUsuario { get; set; }
        
    }
}
