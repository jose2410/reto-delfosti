﻿using Microsoft.EntityFrameworkCore;

namespace WebApiDelfosti.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> opt) : base(opt)
        {

        }

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Rol> Roles { get; set; }
        public DbSet<Pedido> Pedidos { get; set; }
        public DbSet<EstadoPedido> EstadosPedidos { get; set; }
        public DbSet<Producto> Productos { get; set; }
        public DbSet<PedidoProducto> PedidoProductos { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PedidoProducto>().HasKey(pp => new { pp.NumeroPedido, pp.SKU });

            modelBuilder.Entity<Pedido>()
                .HasOne(p => p.VendedorUsuario)
                .WithMany()
                .HasForeignKey(p => p.VendedorSolicitante)
                .OnDelete(DeleteBehavior.NoAction);

            modelBuilder.Entity<Pedido>()
                .HasOne(p => p.RepartidorUsuario)
                .WithMany()
                .HasForeignKey(p => p.Repartidor)
                .OnDelete(DeleteBehavior.NoAction);

        }

    }
}
