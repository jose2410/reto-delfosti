﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApiDelfosti.Models
{
    public class PedidoProducto
    {
        public int NumeroPedido { get; set; }
        public int SKU { get; set; }
        public int Cantidad { get; set; }

        public Pedido Pedido { get; set; }

        public Producto Producto { get; set; }
    }
}
