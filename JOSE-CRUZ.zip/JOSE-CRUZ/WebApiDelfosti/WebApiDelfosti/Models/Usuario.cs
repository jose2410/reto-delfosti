﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace WebApiDelfosti.Models
{
    public class Usuario
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CodigoTrabajador { get; set; }
        [Required]
        public string NombreUsuario { get; set; }
        [Required]
        public string Contrasenia { get; set; }
        [Required]
        public string Nombre { get; set; }
        [Required]
        public string CorreoElectronico { get; set; }
        public string Telefono { get; set; }
        [Required]
        public string Puesto { get; set; }
        [Required]
        public int RolID { get; set; } // Esta es la clave foránea que relaciona a los usuarios con los roles
        public Rol Rol { get; set; }
    }
}
