﻿using WebApiDelfosti.Models;

namespace WebApiDelfosti.Services
{
    public interface IUsuarioService
    {
        IEnumerable<Usuario> ListarUsuariosPorRol(string rol);
        Usuario ObtenerUsuarioPorNombreUsuario(string nombreUsuario);
        bool ValidarContraseña(string password, string password_almacenado);
    }
}
