﻿using WebApiDelfosti.Models;

namespace WebApiDelfosti.Services
{
    public class UsuarioService : IUsuarioService
    {
        private readonly ApplicationDbContext _context;

        public UsuarioService(ApplicationDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Usuario> ListarUsuariosPorRol(string rol)
        {
            // Realizar la consulta en la base de datos para filtrar los usuarios por rol
            var usuariosPorRol = _context.Usuarios.Where(u => u.Rol.Nombre == rol).ToList();

            return usuariosPorRol;
        }

        public Usuario ObtenerUsuarioPorNombreUsuario(string nombreUsuario)
        {
            // Obtiene un usuario por su nombre de usuario
            var u = _context.Usuarios.FirstOrDefault(u => u.NombreUsuario == nombreUsuario);
            if (u != null)
            {
                return u;
            }
            return null;
        }
        public bool ValidarContraseña(string password, string password_almacenada)
        {
            // Valida un usuario por su contraseña ingresada y contraseña extraida de la consulta anterior
            var u = _context.Usuarios.FirstOrDefault(u => u.Contrasenia == password && u.Contrasenia == password_almacenada);
            if (u != null)
            {
                return true;
            }
            else
            {
                return false;
            }           
        }
    }
}
