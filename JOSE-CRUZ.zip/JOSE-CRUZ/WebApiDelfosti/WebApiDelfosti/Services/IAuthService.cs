﻿using WebApiDelfosti.Models;

namespace WebApiDelfosti.Services
{
    public interface IAuthService
    {
        string GenerarToken(Usuario usuario);
        bool ValidarToken(string token);
        Usuario IniciarSesion(string nombreUsuario, string contraseña);
    }
}
