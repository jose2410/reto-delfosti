﻿using WebApiDelfosti.Models;

namespace WebApiDelfosti.Services
{
    public class ProductoService : IProductoService
    {
        private readonly ApplicationDbContext _context;

        public ProductoService(ApplicationDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Producto> ListarProductosPorFiltro(string filtro)
        {
            // Implementa la lógica para filtrar productos por SKU o nombre
            return _context.Productos
                .Where(p => p.SKU.ToString().Contains(filtro) || p.Nombre.Contains(filtro))
                .ToList();
        }
    }
}
