﻿using WebApiDelfosti.Models;

namespace WebApiDelfosti.Services
{
    public interface IProductoService
    {
        IEnumerable<Producto> ListarProductosPorFiltro(string filtro);
    }
}
