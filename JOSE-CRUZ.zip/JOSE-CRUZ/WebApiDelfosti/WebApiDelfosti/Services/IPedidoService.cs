﻿using WebApiDelfosti.Models;

namespace WebApiDelfosti.Services
{
    public interface IPedidoService
    {
        Pedido CrearPedido(Pedido pedido);
        Pedido CambiarEstadoPedido(int numeroPedido, int nuevoEstadoId);
        Pedido ObtenerPedidoPorNumero(int numeroPedido);
        //PedidoDetalle ObtenerDetallePedido(int numeroPedido);
    }
}
