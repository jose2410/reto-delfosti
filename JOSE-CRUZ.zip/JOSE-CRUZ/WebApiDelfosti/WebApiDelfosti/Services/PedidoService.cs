﻿using WebApiDelfosti.Models;

namespace WebApiDelfosti.Services
{
    public class PedidoService : IPedidoService
    {
        private readonly ApplicationDbContext _context;

        public PedidoService(ApplicationDbContext context)
        {
            _context = context;
        }

        public Pedido CrearPedido(Pedido pedido)
        {
            // Validar el pedido 

            _context.Pedidos.Add(pedido);
            _context.SaveChanges();

            return pedido;
        }

        public Pedido CambiarEstadoPedido(int numeroPedido, int nuevoEstadoId)
        {
            var pedido = _context.Pedidos.Find(numeroPedido);

            if (pedido == null)
            {
                // Pedido no existe
                throw new ArgumentException("El pedido no existe.");
            }

            if (pedido.EstadoPedidoID == nuevoEstadoId)
            {
                // El estado no cambia
                throw new ArgumentException("El estado no cambia.");
            }

            if (EsCambioDeEstadoPermitido(pedido.EstadoPedidoID, nuevoEstadoId))
            {
                pedido.EstadoPedidoID = nuevoEstadoId;

                // Registrar la fecha de gestión correspondiente
                switch (nuevoEstadoId)
                {
                    case 1:
                        pedido.FechaPedido = DateTime.Now;
                        break;
                    case 2:
                        pedido.FechaRecepcion = DateTime.Now;
                        break;
                    case 3:
                        pedido.FechaDespacho = DateTime.Now;
                        break;
                    case 4:
                        pedido.FechaEntrega = DateTime.Now;
                        break;
                }

                _context.SaveChanges();
            }
            else
            {
                // Manejar el caso en que el cambio de estado no está permitido
                throw new ArgumentException("Cambio de estado no permitido.");
            }

            return pedido;
        }

        private bool EsCambioDeEstadoPermitido(int estadoActualId, int nuevoEstadoId)
        {
            // Define las reglas para permitir cambios de estado jerárquicos aquí
            // Implementar lógica para permitir solo cambios ascendentes (1 -> 2, 2 -> 3, 3 -> 4)

            // Se permite cualquier cambio de estado
            return nuevoEstadoId > estadoActualId;
        }
        public Pedido ObtenerPedidoPorNumero(int numeroPedido)
        {
            // Implementa la lógica para obtener un pedido por su número de pedido
            var p = _context.Pedidos.FirstOrDefault(p => p.NumeroPedido == numeroPedido);

            if (p != null)
            {
                return p;
            }
            return null;
        }
        

    }

}
