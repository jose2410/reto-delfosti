﻿using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using WebApiDelfosti.Models;

namespace WebApiDelfosti.Services
{
    public class AuthService : IAuthService
    {
        private readonly IConfiguration _configuration; // Configuración para JWT
        private readonly IUsuarioService _userService; // Servicio que gestiona los usuarios

        public AuthService(IConfiguration configuration, IUsuarioService userService)
        {
            _configuration = configuration;
            _userService = userService;
        }

        public string GenerarToken(Usuario usuario)
        {
            //Clase para manejar tokens JWT Json Web tokens
            var tokenHandler = new JwtSecurityTokenHandler();
            //Se obtiene la clave secreta para firmar el token se almacena en una cadena y se convierte en un arreglo de bytes
            var key = Encoding.ASCII.GetBytes(_configuration["JwtSettings:Secret"]);
            //Se configura el token JWT
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                //Propiedad subject crea una identidad para asignar el valor del códigotrabajador del usuario y identificar al usuario en el token
                Subject = new ClaimsIdentity(new[]
                {
                new Claim(ClaimTypes.Name, usuario.CodigoTrabajador.ToString())
                }),
                //Establece la fecha y hora de expiración del token, se calcula la fecha y hora actual y se le suma la cantidad de horas definida en la configuracion del token
                Expires = DateTime.UtcNow.AddHours(int.Parse(_configuration["JwtSettings:ExpirationHours"])),
                //Se utiliza el algoritmo HMACSHA256 para firmar el token 
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            //Se crea un objeto de token JWT con la configuración de tokenDescriptor
            var token = tokenHandler.CreateToken(tokenDescriptor);
            //Convierte el token JWT en una cadena
            return tokenHandler.WriteToken(token);
        }

        public bool ValidarToken(string token)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_configuration["JwtSettings:Secret"]);

            try
            {
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    ClockSkew = TimeSpan.Zero
                }, out SecurityToken validatedToken);

                return true;
            }
            catch
            {
                return false;
            }
        }

        public Usuario IniciarSesion(string nombreUsuario, string contrasenia)
        {
            // Verifica las credenciales y retorna el usuario autenticado
            var usuario = _userService.ObtenerUsuarioPorNombreUsuario(nombreUsuario);

            if (usuario != null && _userService.ValidarContraseña(contrasenia, usuario.Contrasenia))
            {
                return usuario;
            }

            return null; // Retorna null si la autenticación falla
        }

    }
}
