﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApiDelfosti.Services;

namespace WebApiDelfosti.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductoController : ControllerBase
    {
        private readonly IProductoService _productoService;

        public ProductoController(IProductoService productoService)
        {
            _productoService = productoService;
        }

        [HttpGet("filtrar")]
        public IActionResult ListarProductosFiltrados(string filtro)
        {
            if (string.IsNullOrEmpty(filtro))
            {
                return BadRequest("El filtro no puede estar vacío");
            }

            var productosFiltrados = _productoService.ListarProductosPorFiltro(filtro);

            if (productosFiltrados.Any())
            {
                return Ok(productosFiltrados);
            }

            return NotFound("No se encontraron productos que coincidan con el filtro");
        }
    }
}
