﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApiDelfosti.Models;
using WebApiDelfosti.Services;

namespace WebApiDelfosti.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PedidoController : ControllerBase
    {
        private readonly IPedidoService _pedidoService;

        public PedidoController(IPedidoService pedidoService)
        {
            _pedidoService = pedidoService;
        }

        [HttpPost("crear")]
        public IActionResult CrearPedido([FromBody] Pedido pedido)
        {
            try
            {
                var nuevoPedido = _pedidoService.CrearPedido(pedido);
                return Ok(nuevoPedido);
            }
            catch (Exception ex)
            {
                // Manejar errores
                return StatusCode(500, "Error interno del servidor");
            }
        }

        [HttpPost("cambiar-estado")]
        public IActionResult CambiarEstadoPedido(int numeroPedido, int nuevoEstadoId)
        {
            try
            {
                var pedido = _pedidoService.CambiarEstadoPedido(numeroPedido, nuevoEstadoId);
                return Ok(pedido);
            }
            catch (Exception ex)
            {
                // Manejar errores
                return StatusCode(500, "Error interno del servidor");
            }
        }
        [HttpGet("por-numero")]
        public IActionResult ObtenerPedidoPorNumero(int numeroPedido)
        {
            if (numeroPedido <= 0)
            {
                return BadRequest("El número de pedido debe ser un valor positivo");
            }

            var pedido = _pedidoService.ObtenerPedidoPorNumero(numeroPedido);

            if (pedido != null)
            {
                return Ok(pedido);
            }

            return NotFound("No se encontró un pedido con ese número");
        }

        //[HttpGet("detalle")]
        //public IActionResult ObtenerDetallePedido(int numeroPedido)
        //{
        //    if (numeroPedido <= 0)
        //    {
        //        return BadRequest("El número de pedido debe ser un valor positivo");
        //    }

        //    var pedidoDetalle = _pedidoService.ObtenerDetallePedido(numeroPedido);

        //    if (pedidoDetalle != null)
        //    {
        //        return Ok(pedidoDetalle);
        //    }

        //    return NotFound("No se encontró un pedido con ese número");
        //}
    }
}
