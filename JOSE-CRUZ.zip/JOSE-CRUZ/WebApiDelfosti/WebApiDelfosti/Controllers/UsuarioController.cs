﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApiDelfosti.Models;
using WebApiDelfosti.Services;

namespace WebApiDelfosti.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {

        private readonly IUsuarioService _usuarioService;
        private readonly IAuthService _authService;

        public UsuarioController(IUsuarioService usuarioService, IAuthService authService)
        {
            _usuarioService = usuarioService;
            _authService = authService;
        }

        [HttpGet("por-rol")]
        public IActionResult ListarUsuariosPorRol(string rol)
        {
            try
            {
                var usuarios = _usuarioService.ListarUsuariosPorRol(rol);
                return Ok(usuarios);
            }
            catch (Exception ex)
            {
                // Manejar errores aquí
                return StatusCode(500, "Error interno del servidor");
            }
        }

        [HttpPost("iniciar-sesion")]
        public IActionResult IniciarSesion([FromBody] Usuario credenciales)
        {
            var usuario = _authService.IniciarSesion(credenciales.NombreUsuario, credenciales.Contrasenia);

            if (usuario != null)
            { 
                //Genera token para el usuario
                var token = _authService.GenerarToken(usuario);
                if (token != null)
                {
                    if (_authService.ValidarToken(token))
                    {
                        return Ok(new { Token = token });
                    }
                }  
            }

            return Unauthorized("Autenticación fallida");
        }

        [HttpGet("por-nombre-usuario")]
        public IActionResult ObtenerUsuarioPorNombreUsuario(string nombreUsuario)
        {
            var usuario = _usuarioService.ObtenerUsuarioPorNombreUsuario(nombreUsuario);

            if (usuario != null)
            {
                return Ok(usuario);
            }

            return NotFound("Usuario no encontrado");
        }
    }
}
